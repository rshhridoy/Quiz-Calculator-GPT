package com.example.quizapps

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
