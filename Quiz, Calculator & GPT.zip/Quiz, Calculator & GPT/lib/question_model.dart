class Question {
  final String questionText;
  final List<Answer> answersList;

  Question(this.questionText, this.answersList);
}

class Answer {
  final String answerText;
  final bool isCorrect;

  Answer(this.answerText, this.isCorrect);
}

List<Question> getQuestions() {
  return [
    Question(
      "What is Flutter?",
      [
        Answer("A framework", true),
        Answer("A programming language", false),
        Answer("A database", false),
        Answer("A game engine", false),
      ],
    ),
    Question(
      "Who developed Flutter?",
      [
        Answer("Facebook", false),
        Answer("Adobe", false),
        Answer("Google", true),
        Answer("Microsoft", false),
      ],
    ),
  ];
}
