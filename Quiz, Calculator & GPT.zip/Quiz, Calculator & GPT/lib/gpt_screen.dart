import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class GptScreen extends StatefulWidget {
  @override
  _GptScreenState createState() => _GptScreenState();
}

class _GptScreenState extends State<GptScreen> {
  final TextEditingController _controller = TextEditingController();
  String _response = '';

  Future<void> _fetchResponse() async {
    final String apiKey = 'sk-proj-MqbnJ3e7roMS93N1UxNxT3BlbkFJkEiVwwvFPzFbjAlvEP4e';
    final String apiUrl = 'https://api.openai.com/v1/completions';

    final response = await http.post(
      Uri.parse(apiUrl),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $apiKey',
      },
      body: json.encode({
        'model': 'text-davinci-003',
        'prompt': _controller.text,
        'max_tokens': 100,
      }),
    );

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      setState(() {
        _response = data['choices'][0]['text'].trim();
      });
    } else {
      setState(() {
        _response = 'Failed to get response from GPT-3';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('GPT AI'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(10.0),  // Corrected padding
        child: Column(
          children: [
            TextField(
              controller: _controller,
              decoration: InputDecoration(
                border: OutlineInputBorder(),
                labelText: 'Enter your query',
              ),
            ),
            SizedBox(height: 10),
            ElevatedButton(
              onPressed: _fetchResponse,
              child: Text('Submit'),
            ),
            SizedBox(height: 20),
            Text(
              'Response:',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Text(
              _response,
              style: TextStyle(fontSize: 16),
            ),
          ],
        ),
      ),
    );
  }
}
