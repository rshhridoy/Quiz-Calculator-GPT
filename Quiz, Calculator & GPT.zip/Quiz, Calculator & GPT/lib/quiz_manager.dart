import 'package:flutter/material.dart';
import 'package:quizapps/question_model.dart';


class QuizManager extends StatefulWidget {
  @override
  State<QuizManager> createState() => _QuizManagerState();
}

class _QuizManagerState extends State<QuizManager> {
  List<Question> questionList = getQuestions();
  final _formKey = GlobalKey<FormState>();
  final _questionController = TextEditingController();
  final _answerControllers = List.generate(4, (_) => TextEditingController());
  int? _correctAnswerIndex;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Manage Questions"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Expanded(
              child: ListView.builder(
                itemCount: questionList.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    title: Text(questionList[index].questionText),
                    trailing: IconButton(
                      icon: Icon(Icons.delete),
                      onPressed: () {
                        setState(() {
                          questionList.removeAt(index);
                        });
                      },
                    ),
                    onTap: () {
                      _editQuestion(context, index);
                    },
                  );
                },
              ),
            ),
            ElevatedButton(
              onPressed: () => _addQuestion(context),
              child: Text("Add Question"),
            ),
          ],
        ),
      ),
    );
  }

  void _addQuestion(BuildContext context) {
    _questionController.clear();
    for (var controller in _answerControllers) {
      controller.clear();
    }
    _correctAnswerIndex = null;
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Add Question"),
        content: _questionForm(),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("Cancel"),
          ),
          ElevatedButton(
            onPressed: () {
              if (_formKey.currentState!.validate()) {
                setState(() {
                  questionList.add(
                    Question(
                      _questionController.text,
                      List.generate(
                        _answerControllers.length,
                            (index) => Answer(
                          _answerControllers[index].text,
                          index == _correctAnswerIndex,
                        ),
                      ),
                    ),
                  );
                });
                Navigator.pop(context);
              }
            },
            child: Text("Save"),
          ),
        ],
      ),
    );
  }

  void _editQuestion(BuildContext context, int index) {
    _questionController.text = questionList[index].questionText;
    for (var i = 0; i < _answerControllers.length; i++) {
      _answerControllers[i].text = questionList[index].answersList[i].answerText;
    }
    _correctAnswerIndex = questionList[index].answersList.indexWhere((answer) => answer.isCorrect);
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Edit Question"),
        content: _questionForm(),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("Cancel"),
          ),
          ElevatedButton(
            onPressed: () {
              if (_formKey.currentState!.validate()) {
                setState(() {
                  questionList[index] = Question(
                    _questionController.text,
                    List.generate(
                      _answerControllers.length,
                          (i) => Answer(
                        _answerControllers[i].text,
                        i == _correctAnswerIndex,
                      ),
                    ),
                  );
                });
                Navigator.pop(context);
              }
            },
            child: Text("Save"),
          ),
        ],
      ),
    );
  }

  Widget _questionForm() {
    return Form(
      key: _formKey,
      child: SingleChildScrollView(
        child: Column(
          children: [
            TextFormField(
              controller: _questionController,
              decoration: InputDecoration(labelText: "Question"),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return "Please enter a question";
                }
                return null;
              },
            ),
            SizedBox(height: 16),
            ...List.generate(_answerControllers.length, (index) {
              return Row(
                children: [
                  Expanded(
                    child: TextFormField(
                      controller: _answerControllers[index],
                      decoration: InputDecoration(labelText: "Answer ${index + 1}"),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return "Please enter an answer";
                        }
                        return null;
                      },
                    ),
                  ),
                  Radio<int>(
                    value: index,
                    groupValue: _correctAnswerIndex,
                    onChanged: (value) {
                      setState(() {
                        _correctAnswerIndex = value;
                      });
                    },
                  ),
                ],
              );
            }),
          ],
        ),
      ),
    );
  }
}
